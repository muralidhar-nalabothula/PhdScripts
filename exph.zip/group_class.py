## find the classes of a given point group
from scipy.spatial import cKDTree
import numpy as np
import collections

def point_group_classes(point_group,tol=1e-4):
    # point_group = (nsym,3,3)
    pg_classes  = []
    
    nsym = len(point_group)
    pg_tree = cKDTree(point_group.reshape(nsym,-1))

    for isym in range(nsym):
        sym_conjugates = point_group.transpose(0,2,1)@point_group[isym][None,:,:]@point_group
        dd, ii = pg_tree.query(sym_conjugates.reshape(nsym,-1), k=1)
        if len(dd[dd>tol]) != 0:
            exit("Not a point group")
        s1_tmp = set(ii)
        if s1_tmp not in pg_classes:
            pg_classes.append(s1_tmp)

    return [list(item) for item in set(tuple(row) for row in pg_classes)]


def null_space(A, eps=1e-6):
    #// https://stackoverflow.com/a/1836003 
    u, s, vh = np.linalg.svd(A)
    null_space = np.compress(s <= eps, vh, axis=0)
    return null_space.T

def identify_symm(symm_mat):
    #// return E, I, R, M, S
    #// find the null space of (A-I) 
    det_val = np.linalg.det(symm_mat)
    if abs(abs(det_val)-1) > 1e-6:
        print("Not a symmetric matric. Det is not equal to +-1")
        exit()

    iden_3x3 = np.eye(3)

    #// check inversion
    if np.sum(np.abs(symm_mat + iden_3x3)**2)/3 < 1e-6:
        return ['I']
    
    #// check identity
    diff_symm = symm_mat-iden_3x3
    if np.sum(np.abs(diff_symm)**2)/3 < 1e-6:
        return ['E']
    
    mirror = False
    if det_val < 0:
        mirror = True 
    
    ## find axis or plane of reflection
    axis = null_space(diff_symm)
    axis_dim =  axis.shape[-1]
    symm_type = ''
    if axis_dim == 0:
        symm_type = 'S'
    elif axis_dim == 1:
        symm_type = 'R'
    elif axis_dim ==2 :
        symm_type = 'M'
    
    axis = null_space(det_val*symm_mat-iden_3x3)
    if axis.shape[-1] ==0:
        print(symm_mat)
        print('Error in finding axis')
        exit()
    axis = axis[:,0]
    axis = axis/np.linalg.norm(axis)

    return_list = [symm_type,axis]

    if symm_type == 'M':
        return return_list
    else :
        # in case of rotation/improper-rotation, find the rotation angle
        v_tmp = np.random.rand(3) + axis[[2,0,1]]
        v_tmp = np.cross(v_tmp,axis)
        v_tmp = v_tmp/np.linalg.norm(v_tmp)
        dot_tmp = np.dot(det_val*symm_mat@v_tmp,v_tmp)
        if abs(dot_tmp)>1: dot_tmp = dot_tmp/abs(dot_tmp)
        angle = np.arccos(dot_tmp)
        if det_val < 0: angle = angle - np.pi
        angle = angle/2/np.pi
        angle = int(np.rint(1.0/angle))
        return_list.append(angle)
        return return_list

def find_principal_axis(list_symm_types):
    len_group = len(list_symm_types)
    if len_group == 1:
        return []
    
    sym_types = []
    for i in list_symm_types:
        sym_types.append(i[0])

    if len_group == 2:
        if 'I' in sym_types:
            return []
        elif 'M' in sym_types:
            return []

    nfold = 0
    paxis = np.array([0,0,0])
    for i in list_symm_types:
        if i[0] == 'R' and i[2] > nfold:
            nfold = i[2]
            paxis = i[1]
    
    return list(paxis)

